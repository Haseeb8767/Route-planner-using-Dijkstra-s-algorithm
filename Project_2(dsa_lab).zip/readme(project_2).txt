
The program prompts the user to select the start and end locations from a list of available options (locations) inside of IITH.
It checks if the selected locations are valid (i.e., they exist in the graph).
If valid, it runs Dijkstra's algorithm to compute the shortest travel time and the route.
Finally, the program prints the shortest travel time and the route from the start to the end location.

For more details regarding the project please refer to the ppt of project2 attached in Zip file.

Thank you for reading.....